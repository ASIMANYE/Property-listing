import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget{
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: HomeScreen(),
    );
  }
}
class HomeScreen extends StatefulWidget{
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen>{
  final List<Map<String,String>> homes = [
    {
      "price": "R20 000",
      "title": "Minimax House",
      "location": "Limbang, Indonesia",
      "bedrooms": "4 bedrooms",
      "baths": "4 baths",
      "image": "assets/House1.jpeg"
    },
     {
      "price": "R2 000 000",
      "title": "Villa",
      "location": "Seoul, South Korea",
      "bedrooms": "6 bedrooms",
      "baths": "3 baths",
      "image": "assets/house2.jpeg"
    },
     {
      "price": "R22 000",
      "title": "Famliy House",
      "location": "Penang, Malaysia",
      "bedrooms": "4 bedrooms",
      "baths": "2 baths",
      "image": "assets/House3.jpeg"
    }
  ];
   // Add new house to the list
  void addHouse(Map<String, String> newHouse) {
    setState(() {
      homes.add(newHouse);  // Add the new house to the list
    });
  }
  // Update or remove house details in the list
  void updateHouse(int index, Map<String, String> updatedHome) {
    setState(() {
      if (updatedHome.isEmpty) {
        // Remove the house from the list if it's deleted
        homes.removeAt(index);
      } else {
        // Replace the home at the given index
        homes[index] = updatedHome;
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home Screen"),
        backgroundColor: Colors.blue,
        ),
      body: Container(
        margin: const  EdgeInsets.only(top:50,right:20,left:20),
        child:Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget> [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                const Text("Hello User!",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            ),
            ClipOval(
               child: Image.asset(
               "assets/jenniekim.jpeg",
                width: 40,
                height: 40,
                fit: BoxFit.cover,  // Use BoxFit here to adjust the image
             ),
            ),
         ],
              ),
             const SizedBox(height: 5),
              const Text(
                "Discover",
                style: TextStyle(
                  color:Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
                ),
                const SizedBox(height: 3),
              const Text(
                "Suitable Homes",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                ),
                ),
                const SizedBox(height: 5),
                Row(
                  children:<Widget> [
                   Expanded(
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.white,//will add color later
                        borderRadius: BorderRadius.only( //will edit later
                          bottomLeft:Radius.circular(30),
                          topLeft: Radius.circular(30),
                          bottomRight: Radius.circular(30),
                           )
                        ),
                        child: const TextField(
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: "Find a good home",
                        border: InputBorder.none,
                      ),
                    ),
                      ),
                      ),
                  ],
                  ),
                 const SizedBox(height:10),
                 ElevatedButton(
                  onPressed: (){
                    // Navigate to AddHouseScreen
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddHouseScreen(onAddHouse: addHouse),
                  )
                );
                  },
                  child: const Text("Add New"),
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: ListView.builder(
                      itemCount: homes.length,
                      itemBuilder: (context,index){
                        return ElevatedButton(
                          onPressed: () {
                      // Navigate to DetailScreen and pass the home update callback
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailsScreen(
                            home: homes[index],
                            onUpdate: (updatedHome) => updateHouse(index, updatedHome), // Callback for updating home
                          ),
                        ),
                      );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                          
                            shadowColor: Colors.transparent,
                            //will learn how to remove effects later 
                          ),
                           child: Card(
                          margin: const EdgeInsets.symmetric(vertical: 10),
                          child: Padding(
                            padding:const  EdgeInsets.all(10),
                            child: Row(
                              children:<Widget> [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Image.asset(
                                    homes[index]["image"]!,
                                    width: 100,
                                    height: 100,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Expanded(
                                  child: Column(
                                    children:<Widget> [
                                      Row(
                                        children: [
                                           Text(
                                        homes[index]["price"]!,
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                        ),
                                      ),
                                      ],
                                      ),
                                     
                                      const SizedBox(height: 5),
                                      Row(
                                        children: [
                                          const Icon(
                                            Icons.location_on,
                                             size:20,
                                             color: Colors.black,
                                             ),
                                           Text(homes[index]["location"]!, ),
                                        ],
                                        ),
                                        const SizedBox(height:10),
                                      Row(
                                        children: [
                                          const Icon(
                                            Icons.bed,
                                             size:20,
                                             color: Colors.black,
                                             ),
                                          Text(homes[index]["bedrooms"]!, ),
                                        ],
                                      ),
                                     Row(
                                      children: [
                                        const Icon(
                                          Icons.bathtub,
                                          size:20,
                                          color: Colors.black,
                                          ),
                                        Text(homes[index]["baths"]!, ),
                                      ],
                                      ),
                                      
                                      
                                    ],
                                    ),
                                  ),
                              ],
                              ),
                            ),
                          ), 
                        );
                        
                      },
                      ),
                    ),
          ],
        ),
      ),
    );
  }
}
class DetailsScreen extends StatefulWidget{
  final Map<String,String> home;
  final Function(Map<String, String>) onUpdate;

  const DetailsScreen({super.key, required this.home, required this.onUpdate});
  @override
 State<DetailsScreen> createState() => _DetailScreenState();
}
class _DetailScreenState extends State<DetailsScreen>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail Screen"),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(
                widget.home["image"]!,
                width: double.infinity,
                height: 250,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 20,),
            Text(
              widget.home["title"]!,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(
                  Icons.location_on,
                  size:20,
                  color: Colors.black,
                ),
                Text("Bedrooms: ${widget.home["bedrooms"]!}"),
              ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  const Icon(
                    Icons.bathtub,
                    size: 20,
                    color: Colors.black,
                  ),
                  Text("Bathrooms: ${widget.home["baths"]!}"),
                ],
                ),
                const SizedBox(height:20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                     onPressed: () async {
                    // Navigate to EditScreen when Edit is clicked
                    final updatedHome = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EditScreen(home: widget.home),
                      ),
                    );

                    if (updatedHome != null) {
                      setState(() {
                        widget.home.addAll(updatedHome);  // Update home data
                      });

                      // Pass updated home back to HomeScreen
                      widget.onUpdate(updatedHome);
                    }
                  },
                      child: const Text("Edit")
                      ),
                    ElevatedButton(
                      onPressed: (){
                        showDialog(
                          context: context,
                           builder: (BuildContext context){
                            return AlertDialog(
                              title: const Text("Confirm Delete"),
                              content: const Text(
                                "Are you sure you want to delete this house?"
                              ),
                              actions: [
                                TextButton(
                                  onPressed: (){
                                    Navigator.of(context).pop();
                                  },
                                   child: const Text("Cancel")
                                   ),
                                   ElevatedButton(
                                    onPressed: (){
                                      Navigator.of(context).pop();
                                      widget.onUpdate({});
                                      Navigator.pop(context);
                                    },
                                     style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.red,
                                     ),
                                     child: const Text("Delete"),
                                     ),

                              ],
                            );
                           }
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                     child: const Text("Delete"),
                    
                    ),
                      
                  ],
                  ),
          ],
        ),
        ),
    );
  }
}
class EditScreen extends StatefulWidget{
  final Map<String, String> home;

  const EditScreen({super.key, required this.home});

  @override
  State<EditScreen> createState() => _EditScreenState();
}
class _EditScreenState extends State<EditScreen>{

  late TextEditingController priceController;
  late TextEditingController locationController;
  late TextEditingController titleController;
  late TextEditingController bedroomsController;
  late TextEditingController bathsController;

  @override
  void initState(){
    super.initState();
    //Initialize controller with the existing house data:
    priceController = TextEditingController(text: widget.home["price"]);
    locationController = TextEditingController(text: widget.home["location"]);
    titleController = TextEditingController(text: widget.home["title"]);
    bedroomsController = TextEditingController(text: widget.home["bedrooms"]);
    bathsController = TextEditingController(text: widget.home["baths"]);
  }
  @override
  void dispose(){
    priceController.dispose();
    locationController.dispose();
    titleController.dispose();
    locationController.dispose();
    bedroomsController.dispose();
    bathsController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Edit Screen"),
        backgroundColor: Colors.blue,
      ),
      body:Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextField(
              controller: priceController,
              decoration: const InputDecoration(labelText: "Price"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: "Title"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: locationController,
              decoration: const InputDecoration(labelText: "Location"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: bedroomsController,
              decoration: const InputDecoration(labelText: "Bedrooms"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: bathsController,
              decoration: const InputDecoration(labelText: "Bathrooms"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: (){
              setState(() {
                  widget.home["price"] = priceController.text;
                  widget.home["title"] = titleController.text;
                  widget.home["location"] = locationController.text;
                  widget.home["bedrooms"] = bedroomsController.text;
                  widget.home["baths"] = bathsController.text;
                });
                 Navigator.pop(context, widget.home); // Pass the updated home back
            },
             child: const Text("Save Changes"),
             )
          ],
        ),
        ),
      
    );
  }
}
class AddHouseScreen extends StatefulWidget{
  final Function (Map<String, String>) onAddHouse;
  const AddHouseScreen({super.key, required this.onAddHouse});

  @override
  State<AddHouseScreen> createState()=> _AddHouseScreen();
}
class _AddHouseScreen extends State<AddHouseScreen>{
  final TextEditingController priceController = TextEditingController();
  final TextEditingController titleController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController bedroomsController = TextEditingController();
  final TextEditingController bathsController = TextEditingController();
  final TextEditingController imageController = TextEditingController();

  @override
  void dispose(){
    priceController.dispose();
    titleController.dispose();
    locationController.dispose();
    bedroomsController.dispose();
    bathsController.dispose();
    imageController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add New House"),
        backgroundColor: Colors.blue,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget> [
              TextField(
                controller: priceController,
                decoration: const InputDecoration(labelText: "Price"),
              ),
              const SizedBox(height: 10),
              const SizedBox(height: 10),
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: "Title"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: locationController,
              decoration: const InputDecoration(labelText: "Location"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: bedroomsController,
              decoration: const InputDecoration(labelText: "Bedrooms"),
            ),
             const SizedBox(height: 10),
            TextField(
              controller: bathsController,
              decoration: const InputDecoration(labelText: "Bathrooms"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: imageController,
              decoration: const InputDecoration(labelText: "Image Asset Path"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: (){
                // Create a new house map and pass it back to the HomeScreen
                Map<String, String> newHouse = {
                  "price": priceController.text,
                  "title": titleController.text,
                  "location": locationController.text,
                  "bedrooms": bedroomsController.text,
                  "baths": bathsController.text,
                  "image": imageController.text.isNotEmpty
                      ? imageController.text
                      : "assets/default_house.jpeg", // Default image if empty
                };
                widget.onAddHouse(newHouse); // Pass the new house to HomeScreen
                Navigator.pop(context); // Close the AddHouseScreen
              },
               child: const Text("Add House"),
               ),
            ],
            ),
          ),
    );
  }
}